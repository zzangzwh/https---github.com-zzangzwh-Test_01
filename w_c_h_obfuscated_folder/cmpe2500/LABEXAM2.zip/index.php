<?php

require_once('dbUtil.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXAM</title>
</head>
<body>
    <section id="Question0"></section>
    <section id="Question1"></section>
    <section id="Question2"></section>
    <section class="error"></section>
</body>

<script src="js/main.js"></script>
    <script src="js/setting.js"></script>
</html>