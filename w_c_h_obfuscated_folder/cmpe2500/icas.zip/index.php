<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>icas</title>
</head>
<body>
    <section>
        <ol>
            <li ><a href="week01.php">ICA01_WEEK01</a></li>
            <!-- <li ><a href="week02.php">ICA01_WEEK01</a></li> -->
        </ol>
    </section>
</body>
</html>