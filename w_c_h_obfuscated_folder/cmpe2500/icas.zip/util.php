<?php
function generateNumbers()
{
    $a = array();
    for($i = 0; $i <10; $i++){
        $a[$i] =$i+1;

    }
    shuffle($a);
    return $a;
}
function makeList($collection)
{
    $output = "<ol>";
    foreach($collection as $value){
        $output .= "<li>$value</li>";
    }
    $output .= "</ol>";

    return $output;

}